# TP IPv6 : réseau de 4 routeurs avec RIPng (Packet Tracer)

## Objectif
Configurer un réseau IPv6 composé de 4 routeurs reliés en anneau par des liens série, avec un routage dynamique RIPng, et vérifier la communication entre les différents réseaux locaux (LAN).

## Outils
- Cisco Packet Tracer

## Topologie
- 4 routeurs (R0, R1, R2, R3) reliés en anneau : R0–R1, R1–R2, R2–R3, R3–R0
- 2 réseaux locaux (LAN) par routeur
- Routage dynamique : RIPng (processus `TP`)

*(Ajoutez ici une capture d'écran de la topologie : `captures/topologie.png`)*

## Plan d'adressage

| Routeur | Interface | Adresse IPv6 | Rôle |
|---------|-----------|--------------|------|
| R0 | g0/0/0 | 2001:0118:acad:0001::1/64 | LAN |
| R0 | g0/0/1 | 2001:0118:acad:0003::1/64 | LAN |
| R0 | s0/1/0 | 2001:0118:acad:0010::1/64 | Lien R0–R3 |
| R0 | s0/1/1 | 2001:0118:acad:0007::1/64 | Lien R0–R1 |
| R1 | g0/0/0 | 2001:0118:acad:0006::1/64 | LAN |
| R1 | g0/0/1 | 2001:0118:acad:0002::1/64 | LAN |
| R1 | s0/1/0 | 2001:0118:acad:0007::2/64 | Lien R0–R1 |
| R1 | s0/1/1 | 2001:0118:acad:0008::1/64 | Lien R1–R2 |
| R2 | g0/0/0 | 2001:0118:acad:0004::1/64 | LAN |
| R2 | g0/0/1 | 2001:0118:acad:0005::1/64 | LAN |
| R2 | s0/1/0 | 2001:0118:acad:0008::2/64 | Lien R1–R2 |
| R2 | s0/1/1 | 2001:0118:acad:0009::2/64 | Lien R2–R3 |
| R3 | g0/0/0 | 2001:0118:acad:0016::1/64 | LAN |
| R3 | g0/0/1 | 2001:0118:acad:0015::1/64 | LAN |
| R3 | s0/1/0 | 2001:0118:acad:0010::2/64 | Lien R0–R3 |
| R3 | s0/1/1 | 2001:0118:acad:0009::1/64 | Lien R2–R3 |

## Étapes réalisées
1. Création de la topologie dans Packet Tracer
2. Activation du routage IPv6 sur chaque routeur : `ipv6 unicast-routing`
3. Configuration des adresses globales et link-local sur chaque interface
4. Activation de RIPng sur toutes les interfaces : `ipv6 rip TP enable`
5. Configuration du `clock rate` côté DCE des liens série
6. Sauvegarde de la configuration : `wr`

Exemple de configuration (R0) :

```
enable
conf t
ipv6 unicast-routing

interface g0/0/0
ipv6 address FE80::1:1 link-local
ipv6 address 2001:0118:acad:0001::1/64
ipv6 rip TP enable
no shutdown

ipv6 router rip TP
end
wr
```

Les commandes complètes de chaque routeur sont dans `commandes_ipv6.txt`.

## Vérification
Commandes utilisées pour tester :
- `show ipv6 interface brief` : état et adresses des interfaces
- `show ipv6 route` : routes apprises par RIPng (marquées `R`)
- `ping` entre des machines de LAN différents

Résultat : la communication fonctionne entre les réseaux locaux.

*(Ajoutez ici 2 captures : `captures/show-ipv6-route.png` et `captures/ping.png`)*

## Fichiers
- `TPE_IPV6.pkt` : fichier Packet Tracer
- `commandes_ipv6.txt` : commandes de configuration des 4 routeurs
- `captures/` : captures d'écran
